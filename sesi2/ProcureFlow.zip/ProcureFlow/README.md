# ProcureFlow

ProcureFlow adalah aplikasi pengadaan multi-tenant untuk latihan analisis source code dengan AI coding agent. Aplikasi ini sengaja memuat kelemahan keamanan dan hanya boleh dijalankan pada komputer atau VM lab milik peserta.

Jangan mempublikasikan aplikasi ke Internet, jaringan kantor, atau Wi-Fi bersama. Konfigurasi Compose hanya membuka web application pada `127.0.0.1`.

## Prasyarat

- Docker Engine atau Docker Desktop dengan Docker Compose;
- minimal 2 GB RAM kosong;
- browser modern;
- OpenCode dan model AI yang ditentukan instruktur.

Build pertama memerlukan image dan dependency yang sudah diunduh. Instruktur dapat melakukan pre-pull sebelum kelas. Setelah image selesai dibangun, aplikasi tidak membutuhkan layanan cloud saat runtime.

## Menjalankan aplikasi

Dari folder hasil ekstraksi:

```bash
docker compose up --build -d
```

Tunggu sampai seluruh container sehat:

```bash
docker compose ps
```

Buka [http://127.0.0.1:3000](http://127.0.0.1:3000). Mailbox lokal tersedia di [http://127.0.0.1:3000/lab/mailbox](http://127.0.0.1:3000/lab/mailbox).

Jika port `3000` sudah dipakai, buat file `.env` berikut sebelum menjalankan Compose:

```dotenv
PROCUREFLOW_HOST_PORT=3300
```

Kemudian buka `http://127.0.0.1:3300`.

## Akun demo

Semua akun menggunakan password `ProcureFlow!2026`.

| Email                    | Role awal | Organisasi awal    |
| ------------------------ | --------- | ------------------ |
| `alex@northwind.example` | employee  | Northwind Workshop |
| `employee@acme.example`  | employee  | Acme Manufacturing |
| `manager@acme.example`   | manager   | Acme Manufacturing |
| `finance@acme.example`   | finance   | Acme Manufacturing |
| `vendor@beacon.example`  | vendor    | Acme Manufacturing |
| `admin@acme.example`     | admin     | Acme Manufacturing |

Seluruh akun, organisasi, invoice, dan dokumen merupakan data dummy.

## Struktur runtime

```text
Browser
  -> app
     -> PostgreSQL
     -> database-backed job queue
        -> worker
           -> internal lab network
              -> partner gateway / internal ledger simulator
```

Container utama:

- `app`: HTTP routes, session, UI, dan fungsi bisnis;
- `db`: PostgreSQL untuk data aplikasi, session, dan job;
- `worker`: memproses webhook delivery dan export job;
- `internal-service`: mensimulasikan partner gateway dan ledger internal tanpa membuka port ke host.

## Alur bisnis yang tersedia

- login, logout, dan pergantian organisasi;
- invitation dan membership;
- pembuatan, submit, serta approval purchase request;
- invoice vendor dan review finance;
- konfigurasi serta pengujian webhook;
- pembuatan dan download procurement export;
- audit activity dan mailbox lokal.

## Reset data lab

Reset menghapus perubahan pada database ProcureFlow dan membuat ulang deterministic seed:

```bash
docker compose exec -T app node dist/src/reset.js
```

Session browser ikut terhapus. Muat ulang halaman dan login kembali setelah reset.

Untuk menghentikan aplikasi tanpa menghapus data:

```bash
docker compose stop
```

Untuk menghentikan aplikasi dan menghapus volume database lab:

```bash
docker compose down -v
```

Perintah terakhir hanya boleh dijalankan dari folder ProcureFlow karena menghapus volume Compose milik lab ini.

## Log dan troubleshooting

Lihat status:

```bash
docker compose ps
```

Lihat log aplikasi dan worker:

```bash
docker compose logs app worker
```

Jika health check gagal, pastikan port host tersedia dan Docker mempunyai RAM yang cukup. Reset data jika state lab tidak lagi sesuai dengan langkah reproduksi.

## Pengumpulan laporan

Baca `ASSESSMENT_RULES.md`, lalu isi `REPORT_TEMPLATE.docx`. Versi Markdown (`REPORT_TEMPLATE.md`) disediakan sebagai alternatif untuk peserta yang menyusun laporan dengan text editor. Temuan harus didukung lokasi source, aliran data atau state, dan evidence dari instance lokal.
