CREATE TABLE IF NOT EXISTS tenants (
  id text PRIMARY KEY,
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id text PRIMARY KEY,
  email text NOT NULL UNIQUE,
  display_name text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vendors (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);

CREATE TABLE IF NOT EXISTS memberships (
  id text PRIMARY KEY,
  user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('employee', 'manager', 'finance', 'vendor', 'admin')),
  vendor_id text REFERENCES vendors(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, tenant_id)
);

CREATE TABLE IF NOT EXISTS purchase_requests (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  requester_id text NOT NULL REFERENCES users(id),
  vendor_id text REFERENCES vendors(id),
  title text NOT NULL,
  description text NOT NULL,
  state text NOT NULL CHECK (state IN ('draft', 'submitted', 'approved', 'invoiced', 'exported')),
  budget_cents integer NOT NULL CHECK (budget_cents >= 0),
  export_artifact_key text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invitations (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('employee', 'manager', 'finance', 'vendor', 'admin')),
  vendor_id text REFERENCES vendors(id),
  onboarding_request_id text REFERENCES purchase_requests(id),
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  accepted_by text REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invoices (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  purchase_request_id text NOT NULL REFERENCES purchase_requests(id),
  vendor_id text NOT NULL REFERENCES vendors(id),
  note text NOT NULL,
  attachment_name text NOT NULL,
  amount_cents integer NOT NULL CHECK (amount_cents >= 0),
  created_by text NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS webhook_configs (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vendor_id text NOT NULL REFERENCES vendors(id),
  callback_url text NOT NULL,
  created_by text NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
  id text PRIMARY KEY,
  webhook_id text NOT NULL REFERENCES webhook_configs(id) ON DELETE CASCADE,
  delivery_mode text NOT NULL DEFAULT 'event' CHECK (delivery_mode IN ('event', 'diagnostic')),
  status text NOT NULL CHECK (status IN ('pending', 'processing', 'succeeded', 'failed')),
  response_status integer,
  response_body text,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

ALTER TABLE webhook_deliveries
  ADD COLUMN IF NOT EXISTS delivery_mode text NOT NULL DEFAULT 'event'
  CHECK (delivery_mode IN ('event', 'diagnostic'));

CREATE TABLE IF NOT EXISTS export_jobs (
  id text PRIMARY KEY,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  requested_by text NOT NULL REFERENCES users(id),
  artifact_key text NOT NULL UNIQUE,
  status text NOT NULL CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

CREATE TABLE IF NOT EXISTS export_artifacts (
  artifact_key text PRIMARY KEY REFERENCES export_jobs(artifact_key) ON DELETE CASCADE,
  tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  content_type text NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lab_messages (
  id text PRIMARY KEY,
  recipient text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  tenant_id text,
  user_id text,
  action text NOT NULL,
  object_type text,
  object_id text,
  detail text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_sessions (
  sid varchar PRIMARY KEY,
  sess json NOT NULL,
  expire timestamp(6) NOT NULL
);

CREATE INDEX IF NOT EXISTS memberships_user_idx ON memberships(user_id);
CREATE INDEX IF NOT EXISTS purchase_requests_tenant_idx ON purchase_requests(tenant_id);
CREATE INDEX IF NOT EXISTS webhook_deliveries_status_idx ON webhook_deliveries(status, created_at);
CREATE INDEX IF NOT EXISTS export_jobs_status_idx ON export_jobs(status, created_at);
CREATE INDEX IF NOT EXISTS user_sessions_expire_idx ON user_sessions(expire);
