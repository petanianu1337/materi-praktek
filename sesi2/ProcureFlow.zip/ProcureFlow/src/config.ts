function numberFromEnv(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined) return fallback;

  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

export const config = {
  appPort: numberFromEnv("APP_PORT", 3000),
  baseUrl: process.env["BASE_URL"] ?? "http://127.0.0.1:3000",
  databaseUrl:
    process.env["DATABASE_URL"] ?? "postgres://procureflow:procureflow@127.0.0.1:5432/procureflow",
  internalPort: numberFromEnv("INTERNAL_PORT", 4000),
  invitationSecret:
    process.env["INVITATION_SECRET"] ?? "local-training-invitation-secret-change-me",
  partnerHost: process.env["PARTNER_HOST"] ?? "partner-gateway",
  sessionSecret: process.env["SESSION_SECRET"] ?? "local-training-session-secret-change-me",
  workerPollMs: numberFromEnv("WORKER_POLL_MS", 750),
} as const;
