import { closePool, pool } from "./db.js";
import { migrate } from "./migrate.js";
import { seed } from "./seed.js";

async function reset(): Promise<void> {
  await pool.query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await migrate();
  await seed();
}

reset()
  .then(() => {
    console.log("ProcureFlow data was reset");
  })
  .finally(closePool)
  .catch((error: unknown) => {
    console.error("ProcureFlow reset failed", error);
    process.exitCode = 1;
  });
