import { readFile } from "node:fs/promises";
import { join } from "node:path";

import { closePool, pool } from "./db.js";

export async function migrate(): Promise<void> {
  const migrationPath = join(process.cwd(), "db", "migrations", "001_initial.sql");
  const sql = await readFile(migrationPath, "utf8");
  await pool.query(sql);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  migrate()
    .then(() => {
      console.log("Database migration completed");
    })
    .finally(closePool)
    .catch((error: unknown) => {
      console.error("Database migration failed", error);
      process.exitCode = 1;
    });
}
