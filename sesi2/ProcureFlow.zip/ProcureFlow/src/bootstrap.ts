import { closePool } from "./db.js";
import { migrate } from "./migrate.js";
import { seed } from "./seed.js";

async function bootstrap(): Promise<void> {
  await migrate();
  await seed();
}

bootstrap()
  .then(() => {
    console.log("ProcureFlow database is ready");
  })
  .finally(closePool)
  .catch((error: unknown) => {
    console.error("ProcureFlow bootstrap failed", error);
    process.exitCode = 1;
  });
