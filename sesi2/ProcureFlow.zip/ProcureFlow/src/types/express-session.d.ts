import "express-session";

declare module "express-session" {
  interface SessionData {
    activeTenantId?: string;
    csrfToken?: string;
    flash?: {
      kind: "error" | "success";
      message: string;
    };
    userId?: string;
  }
}
