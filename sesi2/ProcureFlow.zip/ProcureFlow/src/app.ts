import { randomBytes, timingSafeEqual } from "node:crypto";
import { join } from "node:path";

import connectPgSimple from "connect-pg-simple";
import express, { type NextFunction, type Request, type Response } from "express";
import session from "express-session";

import { config } from "./config.js";
import { pool } from "./db.js";
import type { Role, UserContext } from "./domain.js";
import { recentAuditForTenant } from "./modules/audit.js";
import {
  authenticate,
  firstTenantForUser,
  hasMembership,
  membershipsForUser,
  userContext,
} from "./modules/auth.js";
import {
  artifactByKey,
  artifactForTenant,
  createExportJob,
  exportJobsForTenant,
} from "./modules/exports.js";
import { prepareFinanceReview } from "./modules/finance-review.js";
import {
  createInvoice,
  invoiceForFinance,
  invoiceForVendor,
  invoicesForTenant,
  invoicesForVendor,
} from "./modules/invoices.js";
import { acceptInvitation, viewInvitation } from "./modules/invitations.js";
import {
  createPurchaseRequest,
  requestForActiveMember,
  requestInTenant,
  requestsForTenant,
  requestsForVendor,
  transitionPurchaseRequest,
} from "./modules/procurement.js";
import { createWebhook, queueWebhookTest, webhooksForVendor } from "./modules/webhooks.js";

const PgSessionStore = connectPgSimple(session);

function stringValue(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function positiveInteger(value: unknown): number | null {
  const parsed = Number.parseInt(stringValue(value), 10);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

function routeParam(request: Request, name: string): string {
  const value = request.params[name];
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`Route parameter ${name} is required`);
  }
  return value;
}

function sessionRegenerate(request: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    request.session.regenerate((error) => {
      if (error === undefined || error === null) resolve();
      else reject(error);
    });
  });
}

function sessionDestroy(request: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    request.session.destroy((error) => {
      if (error === undefined || error === null) resolve();
      else reject(error);
    });
  });
}

function sessionSave(request: Request): Promise<void> {
  return new Promise((resolve, reject) => {
    request.session.save((error) => {
      if (error === undefined || error === null) resolve();
      else reject(error);
    });
  });
}

function csrfMatches(expected: string | undefined, actual: string): boolean {
  if (expected === undefined) return false;
  const expectedBytes = Buffer.from(expected);
  const actualBytes = Buffer.from(actual);
  return expectedBytes.length === actualBytes.length && timingSafeEqual(expectedBytes, actualBytes);
}

function currentUser(response: Response): UserContext {
  const value: unknown = response.locals["currentUser"];
  if (value === null || value === undefined) throw new Error("Authentication is required");
  return value as UserContext;
}

function requireLogin(request: Request, response: Response, next: NextFunction): void {
  if (response.locals["currentUser"] === null || response.locals["currentUser"] === undefined) {
    request.session.flash = { kind: "error", message: "Sign in to continue" };
    response.redirect(303, "/login");
    return;
  }
  next();
}

function requireRole(...allowedRoles: Role[]) {
  return (request: Request, response: Response, next: NextFunction): void => {
    if (response.locals["currentUser"] === null || response.locals["currentUser"] === undefined) {
      request.session.flash = { kind: "error", message: "Sign in to continue" };
      response.redirect(303, "/login");
      return;
    }
    const user = currentUser(response);
    if (!allowedRoles.includes(user.role)) {
      response.status(403).render("error", {
        message: "Your active role cannot perform this action.",
        title: "Access denied",
      });
      return;
    }
    next();
  };
}

export function createApp(): express.Express {
  const app = express();

  app.set("view engine", "ejs");
  app.set("views", join(process.cwd(), "src", "views"));
  app.disable("x-powered-by");

  app.use((request, response, next) => {
    response.setHeader("X-Content-Type-Options", "nosniff");
    response.setHeader("Referrer-Policy", "no-referrer");
    response.setHeader("X-Frame-Options", "DENY");
    response.setHeader(
      "Content-Security-Policy",
      "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
    );
    next();
  });
  app.use(express.urlencoded({ extended: false, limit: "32kb" }));
  app.use("/assets", express.static(join(process.cwd(), "src", "public"), { fallthrough: false }));
  app.use(
    session({
      cookie: {
        httpOnly: true,
        maxAge: 4 * 60 * 60 * 1000,
        sameSite: "lax",
        secure: false,
      },
      name: "procureflow.sid",
      resave: false,
      saveUninitialized: false,
      secret: config.sessionSecret,
      store: new PgSessionStore({
        conString: config.databaseUrl,
        createTableIfMissing: false,
        tableName: "user_sessions",
      }),
    }),
  );

  app.use(async (request, response, next) => {
    try {
      request.session.csrfToken ??= randomBytes(24).toString("base64url");
      response.locals["csrfToken"] = request.session.csrfToken;
      response.locals["currentPath"] = request.path;
      response.locals["currentUser"] = null;
      response.locals["memberships"] = [];
      response.locals["flash"] = request.session.flash ?? null;
      delete request.session.flash;
      response.locals["formatMoney"] = (cents: number): string =>
        new Intl.NumberFormat("en-US", {
          currency: "USD",
          style: "currency",
        }).format(cents / 100);

      if (request.session.userId !== undefined && request.session.activeTenantId !== undefined) {
        const context = await userContext(request.session.userId, request.session.activeTenantId);
        if (context !== null) {
          response.locals["currentUser"] = context;
          response.locals["memberships"] = await membershipsForUser(context.id);
        }
      }
      next();
    } catch (error) {
      next(error);
    }
  });

  app.use((request, response, next) => {
    if (request.method !== "POST") {
      next();
      return;
    }
    const actual = stringValue(request.body._csrf);
    if (!csrfMatches(request.session.csrfToken, actual)) {
      response.status(403).render("error", {
        message: "The form token is missing or expired. Reload the page and try again.",
        title: "Request rejected",
      });
      return;
    }
    next();
  });

  app.get("/healthz", async (_request, response) => {
    await pool.query("SELECT 1");
    response.json({ status: "ok" });
  });

  app.get("/", (_request, response) => {
    response.redirect(302, response.locals["currentUser"] === null ? "/login" : "/dashboard");
  });

  app.get("/login", (_request, response) => {
    response.render("login", { title: "Sign in" });
  });

  app.post("/login", async (request, response) => {
    const email = stringValue(request.body.email);
    const password = stringValue(request.body.password);
    const userId = await authenticate(email, password);
    if (userId === null) {
      request.session.flash = { kind: "error", message: "Email or password is incorrect" };
      response.redirect(303, "/login");
      return;
    }
    const tenantId = await firstTenantForUser(userId);
    if (tenantId === null) {
      response.status(403).render("error", {
        message: "This account has no active organization membership.",
        title: "Access denied",
      });
      return;
    }
    await sessionRegenerate(request);
    request.session.userId = userId;
    request.session.activeTenantId = tenantId;
    request.session.csrfToken = randomBytes(24).toString("base64url");
    await sessionSave(request);
    response.redirect(303, "/dashboard");
  });

  app.post("/logout", requireLogin, async (request, response) => {
    await sessionDestroy(request);
    response.clearCookie("procureflow.sid");
    response.redirect(303, "/login");
  });

  app.get("/lab/mailbox", async (_request, response) => {
    const messages = await pool.query<{
      body: string;
      created_at: Date;
      recipient: string;
      subject: string;
    }>("SELECT recipient, subject, body, created_at FROM lab_messages ORDER BY created_at DESC");
    response.render("mailbox", { messages: messages.rows, title: "Lab mailbox" });
  });

  app.post("/tenants/:tenantId/switch", requireLogin, async (request, response) => {
    const user = currentUser(response);
    const tenantId = routeParam(request, "tenantId");
    if (!(await hasMembership(user.id, tenantId))) {
      response.status(403).render("error", {
        message: "You do not belong to that organization.",
        title: "Access denied",
      });
      return;
    }
    request.session.activeTenantId = tenantId;
    response.redirect(303, "/dashboard");
  });

  app.get("/dashboard", requireLogin, async (_request, response) => {
    const user = currentUser(response);
    const purchaseRequests =
      user.role === "vendor" && user.vendorId !== null
        ? await requestsForVendor(user.activeTenantId, user.vendorId)
        : await requestsForTenant(user.activeTenantId);
    const invoices =
      user.role === "vendor" && user.vendorId !== null
        ? await invoicesForVendor(user.activeTenantId, user.vendorId)
        : user.role === "finance" || user.role === "admin"
          ? await invoicesForTenant(user.activeTenantId)
          : [];
    const webhooks =
      user.role === "vendor" && user.vendorId !== null
        ? await webhooksForVendor(user.activeTenantId, user.vendorId)
        : [];
    const exportJobs =
      user.role === "finance" || user.role === "admin"
        ? await exportJobsForTenant(user.activeTenantId)
        : [];
    const audit = await recentAuditForTenant(user.activeTenantId);
    response.render("dashboard", {
      audit,
      exportJobs,
      invoices,
      purchaseRequests,
      title: "Dashboard",
      webhooks,
    });
  });

  app.get("/invitations/:token", async (request, response) => {
    try {
      const invitation = await viewInvitation(routeParam(request, "token"));
      response.render("invitation", { invitation, title: "Organization invitation" });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Invitation could not be opened";
      response.status(404).render("error", { message, title: "Invitation unavailable" });
    }
  });

  app.post("/invitations/:token/accept", requireLogin, async (request, response) => {
    const user = currentUser(response);
    try {
      const accepted = await acceptInvitation(routeParam(request, "token"), user.id);
      request.session.flash = {
        kind: "success",
        message:
          "Invitation accepted. Your new organization is available from the tenant switcher.",
      };
      if (accepted.onboardingRequestId !== null) {
        response.redirect(303, `/purchase-requests/${accepted.onboardingRequestId}`);
        return;
      }
      response.redirect(303, "/dashboard");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Invitation could not be accepted";
      response.status(400).render("error", { message, title: "Invitation rejected" });
    }
  });

  app.get("/purchase-requests/new", requireRole("employee", "admin"), (_request, response) => {
    response.render("purchase-request-form", { title: "New purchase request" });
  });

  app.post("/purchase-requests", requireRole("employee", "admin"), async (request, response) => {
    const user = currentUser(response);
    const title = stringValue(request.body.title);
    const description = stringValue(request.body.description);
    const budgetCents = positiveInteger(request.body.budgetCents);
    if (title.length < 3 || description.length < 5 || budgetCents === null) {
      response.status(400).render("error", {
        message: "Title, description, and a positive budget are required.",
        title: "Purchase request rejected",
      });
      return;
    }
    const requestId = await createPurchaseRequest({
      budgetCents,
      description,
      tenantId: user.activeTenantId,
      title,
      userId: user.id,
    });
    response.redirect(303, `/tenant/purchase-requests/${requestId}`);
  });

  app.get("/tenant/purchase-requests/:requestId", requireLogin, async (request, response) => {
    const user = currentUser(response);
    const purchaseRequest = await requestInTenant(
      user.activeTenantId,
      routeParam(request, "requestId"),
    );
    if (purchaseRequest === null) {
      response.status(404).render("error", {
        message: "Purchase request was not found in the active organization.",
        title: "Not found",
      });
      return;
    }
    response.render("purchase-request", { purchaseRequest, title: purchaseRequest.title });
  });

  app.get("/purchase-requests/:requestId", requireLogin, async (request, response) => {
    const user = currentUser(response);
    const purchaseRequest = await requestForActiveMember(
      user.id,
      user.activeTenantId,
      routeParam(request, "requestId"),
    );
    if (purchaseRequest === null) {
      response.status(404).render("error", {
        message: "Purchase request was not found.",
        title: "Not found",
      });
      return;
    }
    response.render("purchase-request", { purchaseRequest, title: purchaseRequest.title });
  });

  app.post(
    "/tenant/purchase-requests/:requestId/submit",
    requireRole("employee", "admin"),
    async (request, response) => {
      const user = currentUser(response);
      const changed = await transitionPurchaseRequest({
        from: "draft",
        requestId: routeParam(request, "requestId"),
        tenantId: user.activeTenantId,
        to: "submitted",
        userId: user.id,
      });
      if (!changed) {
        response.status(409).render("error", {
          message: "Only a draft request in the active organization can be submitted.",
          title: "State conflict",
        });
        return;
      }
      response.redirect(303, `/tenant/purchase-requests/${routeParam(request, "requestId")}`);
    },
  );

  app.post(
    "/tenant/purchase-requests/:requestId/approve",
    requireRole("manager", "admin"),
    async (request, response) => {
      const user = currentUser(response);
      const changed = await transitionPurchaseRequest({
        from: "submitted",
        requestId: routeParam(request, "requestId"),
        tenantId: user.activeTenantId,
        to: "approved",
        userId: user.id,
      });
      if (!changed) {
        response.status(409).render("error", {
          message: "Only a submitted request in the active organization can be approved.",
          title: "State conflict",
        });
        return;
      }
      response.redirect(303, `/tenant/purchase-requests/${routeParam(request, "requestId")}`);
    },
  );

  app.get("/vendor/invoices/new", requireRole("vendor"), async (_request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    const purchaseRequests = await requestsForVendor(user.activeTenantId, user.vendorId);
    response.render("invoice-form", { purchaseRequests, title: "New invoice" });
  });

  app.post("/vendor/invoices", requireRole("vendor"), async (request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    const note = stringValue(request.body.note);
    const attachmentName = stringValue(request.body.attachmentName);
    const purchaseRequestId = stringValue(request.body.purchaseRequestId);
    const amountCents = positiveInteger(request.body.amountCents);
    if (
      note.length === 0 ||
      note.length > 2_000 ||
      attachmentName.length === 0 ||
      amountCents === null
    ) {
      response.status(400).render("error", {
        message: "Invoice fields are incomplete or invalid.",
        title: "Invoice rejected",
      });
      return;
    }
    const invoiceId = await createInvoice({
      amountCents,
      attachmentName,
      note,
      purchaseRequestId,
      tenantId: user.activeTenantId,
      userId: user.id,
      vendorId: user.vendorId,
    });
    response.redirect(303, `/vendor/invoices/${invoiceId}`);
  });

  app.get("/vendor/invoices/:invoiceId", requireRole("vendor"), async (request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    const invoice = await invoiceForVendor(
      routeParam(request, "invoiceId"),
      user.activeTenantId,
      user.vendorId,
    );
    if (invoice === null) {
      response
        .status(404)
        .render("error", { message: "Invoice was not found.", title: "Not found" });
      return;
    }
    response.render("invoice-vendor", { invoice, title: "Invoice details" });
  });

  app.get(
    "/finance/invoices/:invoiceId/review",
    requireRole("finance", "admin"),
    async (request, response) => {
      const user = currentUser(response);
      const invoice = await invoiceForFinance(
        routeParam(request, "invoiceId"),
        user.activeTenantId,
      );
      if (invoice === null) {
        response.status(404).render("error", {
          message: "Invoice was not found.",
          title: "Not found",
        });
        return;
      }
      response.render("invoice-review", {
        review: prepareFinanceReview(invoice),
        title: "Finance invoice review",
      });
    },
  );

  app.get("/vendor/webhooks", requireRole("vendor"), async (_request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    const webhooks = await webhooksForVendor(user.activeTenantId, user.vendorId);
    response.render("webhooks", { title: "Vendor webhooks", webhooks });
  });

  app.post("/vendor/webhooks", requireRole("vendor"), async (request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    try {
      await createWebhook({
        callbackUrl: stringValue(request.body.callbackUrl),
        tenantId: user.activeTenantId,
        userId: user.id,
        vendorId: user.vendorId,
      });
      response.redirect(303, "/vendor/webhooks");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Webhook could not be created";
      response.status(400).render("error", { message, title: "Webhook rejected" });
    }
  });

  app.post("/vendor/webhooks/:webhookId/test", requireRole("vendor"), async (request, response) => {
    const user = currentUser(response);
    if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
    await queueWebhookTest({
      deliveryMode: "event",
      tenantId: user.activeTenantId,
      userId: user.id,
      vendorId: user.vendorId,
      webhookId: routeParam(request, "webhookId"),
    });
    response.redirect(303, "/vendor/webhooks");
  });

  app.post(
    "/vendor/webhooks/:webhookId/diagnose",
    requireRole("vendor"),
    async (request, response) => {
      const user = currentUser(response);
      if (user.vendorId === null) throw new Error("Vendor account has no vendor profile");
      await queueWebhookTest({
        deliveryMode: "diagnostic",
        tenantId: user.activeTenantId,
        userId: user.id,
        vendorId: user.vendorId,
        webhookId: routeParam(request, "webhookId"),
      });
      response.redirect(303, "/vendor/webhooks");
    },
  );

  app.get("/finance/exports", requireRole("finance", "admin"), async (_request, response) => {
    const user = currentUser(response);
    const exportJobs = await exportJobsForTenant(user.activeTenantId);
    response.render("exports", { exportJobs, title: "Procurement exports" });
  });

  app.post("/finance/exports", requireRole("finance", "admin"), async (_request, response) => {
    const user = currentUser(response);
    await createExportJob({ tenantId: user.activeTenantId, userId: user.id });
    response.redirect(303, "/finance/exports");
  });

  app.get("/exports/artifacts/:artifactKey", requireLogin, async (request, response) => {
    const artifact = await artifactByKey(routeParam(request, "artifactKey"));
    if (artifact === null) {
      response
        .status(404)
        .render("error", { message: "Export was not found.", title: "Not found" });
      return;
    }
    response.type(artifact.contentType).send(artifact.content);
  });

  app.get("/tenant/exports/artifacts/:artifactKey", requireLogin, async (request, response) => {
    const user = currentUser(response);
    const artifact = await artifactForTenant(
      routeParam(request, "artifactKey"),
      user.activeTenantId,
    );
    if (artifact === null) {
      response.status(404).render("error", {
        message: "Export was not found in the active organization.",
        title: "Not found",
      });
      return;
    }
    response.type(artifact.contentType).send(artifact.content);
  });

  app.use((_request, response) => {
    response
      .status(404)
      .render("error", { message: "The requested page does not exist.", title: "Not found" });
  });

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    console.error("Request failed", error);
    if (response.headersSent) return;
    response.status(500).render("error", {
      message: "The operation failed. Check the application logs for details.",
      title: "Application error",
    });
  });

  return app;
}
