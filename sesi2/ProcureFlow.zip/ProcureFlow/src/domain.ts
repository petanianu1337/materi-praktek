export const roles = ["employee", "manager", "finance", "vendor", "admin"] as const;

export type Role = (typeof roles)[number];

export interface UserContext {
  id: string;
  email: string;
  displayName: string;
  activeTenantId: string;
  activeTenantName: string;
  role: Role;
  vendorId: string | null;
}

export interface MembershipSummary {
  tenantId: string;
  tenantName: string;
  role: Role;
}
