import { createApp } from "./app.js";
import { config } from "./config.js";
import { closePool } from "./db.js";

const app = createApp();
const server = app.listen(config.appPort, "0.0.0.0", () => {
  console.log(`ProcureFlow listening on port ${config.appPort}`);
});

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.on(signal, () => {
    server.close(() => {
      closePool()
        .catch((error: unknown) => {
          console.error("Failed to close database pool", error);
        })
        .finally(() => process.exit(0));
    });
  });
}
