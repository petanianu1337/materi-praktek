import express from "express";

import { config } from "./config.js";

const app = express();

app.get("/healthz", (_request, response) => {
  response.json({ status: "ok" });
});

app.get("/forward", (request, response) => {
  const host = request.hostname;
  if (host !== "partner-gateway") {
    response.status(404).json({ error: "Route not found" });
    return;
  }

  const rawTarget = request.query["target"];
  const target = typeof rawTarget === "string" ? rawTarget : "";
  let parsed: URL;
  try {
    parsed = new URL(target);
  } catch {
    response.status(400).json({ error: "Target is invalid" });
    return;
  }
  if (parsed.protocol !== "http:") {
    response.status(400).json({ error: "Only HTTP targets are supported in the lab" });
    return;
  }
  response.redirect(302, parsed.toString());
});

app.post("/events", (request, response) => {
  if (request.hostname !== "partner-gateway") {
    response.status(404).json({ error: "Route not found" });
    return;
  }
  response.status(202).json({ accepted: true, reference: "partner-event-accepted" });
});

app.get("/events", (request, response) => {
  if (request.hostname !== "partner-gateway") {
    response.status(404).json({ error: "Route not found" });
    return;
  }
  response.json({ accepted: true, reference: "partner-event-test" });
});

app.get("/internal/marker", (request, response) => {
  if (request.hostname !== "internal-ledger") {
    response.status(404).json({ error: "Route not found" });
    return;
  }
  response.json({
    classification: "internal-only",
    marker: "LEDGER-INTERNAL-4F21",
    source: "ProcureFlow settlement ledger",
  });
});

app.use((_request, response) => {
  response.status(404).json({ error: "Route not found" });
});

app.listen(config.internalPort, "0.0.0.0", () => {
  console.log(`Internal lab service listening on port ${config.internalPort}`);
});
