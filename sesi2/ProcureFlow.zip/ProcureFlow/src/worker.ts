import { setTimeout as delay } from "node:timers/promises";

import { config } from "./config.js";
import { closePool, pool } from "./db.js";
import { fetchWithDestinationPolicy } from "./modules/http-client.js";

let stopping = false;

async function claimWebhookDelivery(): Promise<{
  callbackUrl: string;
  deliveryMode: "diagnostic" | "event";
  id: string;
} | null> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<{
      callback_url: string;
      delivery_mode: "diagnostic" | "event";
      id: string;
    }>(
      `SELECT d.id, d.delivery_mode, w.callback_url
         FROM webhook_deliveries d
         JOIN webhook_configs w ON w.id = d.webhook_id
        WHERE d.status = 'pending'
        ORDER BY d.created_at
        FOR UPDATE OF d SKIP LOCKED
        LIMIT 1`,
    );
    const row = result.rows[0];
    if (row === undefined) {
      await client.query("COMMIT");
      return null;
    }
    await client.query("UPDATE webhook_deliveries SET status = 'processing' WHERE id = $1", [
      row.id,
    ]);
    await client.query("COMMIT");
    return { callbackUrl: row.callback_url, deliveryMode: row.delivery_mode, id: row.id };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function processWebhookDelivery(): Promise<boolean> {
  const delivery = await claimWebhookDelivery();
  if (delivery === null) return false;

  try {
    const requestOptions = {
      headers: {
        "user-agent": "ProcureFlow-Webhook/1.0",
        "x-procureflow-event": "vendor.test",
      },
      signal: AbortSignal.timeout(5_000),
    };
    const response =
      delivery.deliveryMode === "diagnostic"
        ? await fetchWithDestinationPolicy(delivery.callbackUrl, requestOptions)
        : await fetch(delivery.callbackUrl, { ...requestOptions, redirect: "follow" });
    const responseBody = (await response.text()).slice(0, 2_000);
    await pool.query(
      `UPDATE webhook_deliveries
          SET status = 'succeeded', response_status = $1, response_body = $2, finished_at = now()
        WHERE id = $3`,
      [response.status, responseBody, delivery.id],
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Webhook request failed";
    await pool.query(
      `UPDATE webhook_deliveries
          SET status = 'failed', error_message = $1, finished_at = now()
        WHERE id = $2`,
      [message.slice(0, 500), delivery.id],
    );
  }
  return true;
}

async function claimExportJob(): Promise<{
  artifactKey: string;
  id: string;
  tenantId: string;
} | null> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<{
      artifact_key: string;
      id: string;
      tenant_id: string;
    }>(
      `SELECT id, tenant_id, artifact_key
         FROM export_jobs
        WHERE status = 'pending'
        ORDER BY created_at
        FOR UPDATE SKIP LOCKED
        LIMIT 1`,
    );
    const row = result.rows[0];
    if (row === undefined) {
      await client.query("COMMIT");
      return null;
    }
    await client.query("UPDATE export_jobs SET status = 'processing' WHERE id = $1", [row.id]);
    await client.query("COMMIT");
    return { artifactKey: row.artifact_key, id: row.id, tenantId: row.tenant_id };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function processExportJob(): Promise<boolean> {
  const job = await claimExportJob();
  if (job === null) return false;

  try {
    const tenant = await pool.query<{ name: string }>("SELECT name FROM tenants WHERE id = $1", [
      job.tenantId,
    ]);
    const records = await pool.query<{
      budget_cents: number;
      id: string;
      state: string;
      title: string;
    }>(
      `SELECT id, title, state, budget_cents
         FROM purchase_requests
        WHERE tenant_id = $1
        ORDER BY created_at`,
      [job.tenantId],
    );
    const content = JSON.stringify(
      {
        generatedAt: new Date().toISOString(),
        records: records.rows.map((record) => ({
          budgetCents: record.budget_cents,
          id: record.id,
          state: record.state,
          title: record.title,
        })),
        tenant: tenant.rows[0]?.name ?? job.tenantId,
      },
      null,
      2,
    );
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(
        `INSERT INTO export_artifacts (artifact_key, tenant_id, content_type, content)
         VALUES ($1, $2, 'application/json', $3)`,
        [job.artifactKey, job.tenantId, content],
      );
      await client.query(
        `UPDATE export_jobs SET status = 'completed', finished_at = now() WHERE id = $1`,
        [job.id],
      );
      await client.query(
        `UPDATE purchase_requests
            SET state = 'exported', export_artifact_key = $1
          WHERE tenant_id = $2 AND state <> 'draft'`,
        [job.artifactKey, job.tenantId],
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    await pool.query(
      "UPDATE export_jobs SET status = 'failed', finished_at = now() WHERE id = $1",
      [job.id],
    );
    throw error;
  }
  return true;
}

async function run(): Promise<void> {
  console.log("ProcureFlow worker started");
  while (!stopping) {
    try {
      const handledWebhook = await processWebhookDelivery();
      const handledExport = await processExportJob();
      if (!handledWebhook && !handledExport) await delay(config.workerPollMs);
    } catch (error) {
      console.error("Worker iteration failed", error);
      await delay(config.workerPollMs);
    }
  }
}

for (const signal of ["SIGINT", "SIGTERM"] as const) {
  process.on(signal, () => {
    stopping = true;
  });
}

run()
  .then(closePool)
  .catch((error: unknown) => {
    console.error("ProcureFlow worker stopped unexpectedly", error);
    process.exitCode = 1;
  });
