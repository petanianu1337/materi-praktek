import { randomUUID } from "node:crypto";

import { pool } from "../db.js";
import { writeAudit } from "./audit.js";

export interface ExportArtifact {
  artifactKey: string;
  content: string;
  contentType: string;
  tenantId: string;
}

export interface ExportJobView {
  artifactKey: string;
  createdAt: Date;
  id: string;
  status: string;
}

export async function createExportJob(input: {
  tenantId: string;
  userId: string;
}): Promise<string> {
  const jobId = `job_${randomUUID()}`;
  const artifactKey = `art_${randomUUID()}`;
  await pool.query(
    `INSERT INTO export_jobs (id, tenant_id, requested_by, artifact_key, status)
     VALUES ($1, $2, $3, $4, 'pending')`,
    [jobId, input.tenantId, input.userId, artifactKey],
  );
  await writeAudit({
    action: "export.queued",
    objectId: jobId,
    objectType: "export_job",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return jobId;
}

export async function exportJobsForTenant(tenantId: string): Promise<ExportJobView[]> {
  const result = await pool.query<{
    artifact_key: string;
    created_at: Date;
    id: string;
    status: string;
  }>(
    `SELECT id, artifact_key, status, created_at
       FROM export_jobs
      WHERE tenant_id = $1
      ORDER BY created_at DESC`,
    [tenantId],
  );
  return result.rows.map((row) => ({
    artifactKey: row.artifact_key,
    createdAt: row.created_at,
    id: row.id,
    status: row.status,
  }));
}

export async function artifactByKey(artifactKey: string): Promise<ExportArtifact | null> {
  const result = await pool.query<{
    artifact_key: string;
    content: string;
    content_type: string;
    tenant_id: string;
  }>(
    `SELECT a.artifact_key, a.tenant_id, a.content_type, a.content
       FROM export_artifacts a
       JOIN export_jobs j ON j.artifact_key = a.artifact_key
      WHERE a.artifact_key = $1 AND j.status = 'completed'`,
    [artifactKey],
  );
  const row = result.rows[0];
  if (row === undefined) return null;
  return {
    artifactKey: row.artifact_key,
    content: row.content,
    contentType: row.content_type,
    tenantId: row.tenant_id,
  };
}

export async function artifactForTenant(
  artifactKey: string,
  tenantId: string,
): Promise<ExportArtifact | null> {
  const result = await pool.query<{
    artifact_key: string;
    content: string;
    content_type: string;
    tenant_id: string;
  }>(
    `SELECT a.artifact_key, a.tenant_id, a.content_type, a.content
       FROM export_artifacts a
       JOIN export_jobs j ON j.artifact_key = a.artifact_key
      WHERE a.artifact_key = $1
        AND a.tenant_id = $2
        AND j.tenant_id = $2
        AND j.status = 'completed'`,
    [artifactKey, tenantId],
  );
  const row = result.rows[0];
  if (row === undefined) return null;
  return {
    artifactKey: row.artifact_key,
    content: row.content,
    contentType: row.content_type,
    tenantId: row.tenant_id,
  };
}
