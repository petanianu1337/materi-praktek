import { randomUUID } from "node:crypto";

import { pool } from "../db.js";
import type { Role } from "../domain.js";
import { writeAudit } from "./audit.js";
import { verifyInvitationToken } from "./invitation-token.js";

export interface InvitationView {
  email: string;
  expiresAt: Date;
  role: Role;
  tenantName: string;
  token: string;
}

interface InvitationRecord {
  accepted_at: Date | null;
  email: string;
  expires_at: Date;
  id: string;
  onboarding_request_id: string | null;
  role: Role;
  tenant_id: string;
  tenant_name: string;
  vendor_id: string | null;
}

async function invitationRecord(token: string): Promise<InvitationRecord> {
  const claims = verifyInvitationToken(token);
  const result = await pool.query<InvitationRecord>(
    `SELECT i.id,
            i.tenant_id,
            t.name AS tenant_name,
            i.email,
            i.role,
            i.vendor_id,
            i.onboarding_request_id,
            i.expires_at,
            i.accepted_at
       FROM invitations i
       JOIN tenants t ON t.id = i.tenant_id
      WHERE i.id = $1 AND i.tenant_id = $2`,
    [claims.invitationId, claims.tenantId],
  );
  const invitation = result.rows[0];
  if (invitation === undefined || invitation.email !== claims.email) {
    throw new Error("Invitation does not exist");
  }
  return invitation;
}

export async function viewInvitation(token: string): Promise<InvitationView> {
  const invitation = await invitationRecord(token);
  return {
    email: invitation.email,
    expiresAt: invitation.expires_at,
    role: invitation.role,
    tenantName: invitation.tenant_name,
    token,
  };
}

export async function acceptInvitation(
  token: string,
  userId: string,
): Promise<{ onboardingRequestId: string | null; tenantId: string }> {
  const invitation = await invitationRecord(token);
  if (invitation.accepted_at !== null) throw new Error("Invitation was already accepted");
  if (invitation.expires_at.getTime() <= Date.now()) throw new Error("Invitation has expired");

  if (invitation.role !== "vendor") {
    const userResult = await pool.query<{ email: string }>(
      "SELECT email FROM users WHERE id = $1",
      [userId],
    );
    if (userResult.rows[0]?.email.toLowerCase() !== invitation.email.toLowerCase()) {
      throw new Error("Invitation recipient does not match the signed-in account");
    }
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO memberships (id, user_id, tenant_id, role, vendor_id)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (user_id, tenant_id)
       DO UPDATE SET role = EXCLUDED.role, vendor_id = EXCLUDED.vendor_id`,
      [randomUUID(), userId, invitation.tenant_id, invitation.role, invitation.vendor_id],
    );
    await client.query(
      `UPDATE invitations
          SET accepted_at = now(), accepted_by = $1
        WHERE id = $2 AND accepted_at IS NULL`,
      [userId, invitation.id],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }

  await writeAudit({
    action: "invitation.accepted",
    detail: `Role ${invitation.role} added`,
    objectId: invitation.id,
    objectType: "invitation",
    tenantId: invitation.tenant_id,
    userId,
  });

  return {
    onboardingRequestId: invitation.onboarding_request_id,
    tenantId: invitation.tenant_id,
  };
}
