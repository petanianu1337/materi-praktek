import { randomUUID } from "node:crypto";

import { pool } from "../db.js";
import { writeAudit } from "./audit.js";

export interface InvoiceView {
  amountCents: number;
  attachmentName: string;
  createdAt: Date;
  id: string;
  note: string;
  purchaseRequestId: string;
  purchaseRequestTitle: string;
  tenantId: string;
  vendorId: string;
  vendorName: string;
}

interface InvoiceRow {
  amount_cents: number;
  attachment_name: string;
  created_at: Date;
  id: string;
  note: string;
  purchase_request_id: string;
  purchase_request_title: string;
  tenant_id: string;
  vendor_id: string;
  vendor_name: string;
}

const invoiceSelect = `SELECT i.id,
                              i.tenant_id,
                              i.purchase_request_id,
                              pr.title AS purchase_request_title,
                              i.vendor_id,
                              v.name AS vendor_name,
                              i.note,
                              i.attachment_name,
                              i.amount_cents,
                              i.created_at
                         FROM invoices i
                         JOIN purchase_requests pr ON pr.id = i.purchase_request_id
                         JOIN vendors v ON v.id = i.vendor_id`;

function mapInvoice(row: InvoiceRow): InvoiceView {
  return {
    amountCents: row.amount_cents,
    attachmentName: row.attachment_name,
    createdAt: row.created_at,
    id: row.id,
    note: row.note,
    purchaseRequestId: row.purchase_request_id,
    purchaseRequestTitle: row.purchase_request_title,
    tenantId: row.tenant_id,
    vendorId: row.vendor_id,
    vendorName: row.vendor_name,
  };
}

export async function createInvoice(input: {
  amountCents: number;
  attachmentName: string;
  note: string;
  purchaseRequestId: string;
  tenantId: string;
  userId: string;
  vendorId: string;
}): Promise<string> {
  const request = await pool.query(
    `SELECT 1
       FROM purchase_requests
      WHERE id = $1 AND tenant_id = $2 AND vendor_id = $3`,
    [input.purchaseRequestId, input.tenantId, input.vendorId],
  );
  if (request.rowCount !== 1) throw new Error("Purchase request is not assigned to this vendor");

  const invoiceId = `inv_${randomUUID()}`;
  await pool.query(
    `INSERT INTO invoices
       (id, tenant_id, purchase_request_id, vendor_id, note, attachment_name, amount_cents, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      invoiceId,
      input.tenantId,
      input.purchaseRequestId,
      input.vendorId,
      input.note,
      input.attachmentName,
      input.amountCents,
      input.userId,
    ],
  );
  await pool.query("UPDATE purchase_requests SET state = 'invoiced' WHERE id = $1", [
    input.purchaseRequestId,
  ]);
  await writeAudit({
    action: "invoice.created",
    detail: `Invoice ${invoiceId} received`,
    objectId: invoiceId,
    objectType: "invoice",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return invoiceId;
}

export async function invoiceForVendor(
  invoiceId: string,
  tenantId: string,
  vendorId: string,
): Promise<InvoiceView | null> {
  const result = await pool.query<InvoiceRow>(
    `${invoiceSelect}
      WHERE i.id = $1 AND i.tenant_id = $2 AND i.vendor_id = $3`,
    [invoiceId, tenantId, vendorId],
  );
  const row = result.rows[0];
  return row === undefined ? null : mapInvoice(row);
}

export async function invoiceForFinance(
  invoiceId: string,
  tenantId: string,
): Promise<InvoiceView | null> {
  const result = await pool.query<InvoiceRow>(
    `${invoiceSelect} WHERE i.id = $1 AND i.tenant_id = $2`,
    [invoiceId, tenantId],
  );
  const row = result.rows[0];
  return row === undefined ? null : mapInvoice(row);
}

export async function invoicesForTenant(tenantId: string): Promise<InvoiceView[]> {
  const result = await pool.query<InvoiceRow>(
    `${invoiceSelect} WHERE i.tenant_id = $1 ORDER BY i.created_at DESC`,
    [tenantId],
  );
  return result.rows.map(mapInvoice);
}

export async function invoicesForVendor(
  tenantId: string,
  vendorId: string,
): Promise<InvoiceView[]> {
  const result = await pool.query<InvoiceRow>(
    `${invoiceSelect}
      WHERE i.tenant_id = $1 AND i.vendor_id = $2
      ORDER BY i.created_at DESC`,
    [tenantId, vendorId],
  );
  return result.rows.map(mapInvoice);
}
