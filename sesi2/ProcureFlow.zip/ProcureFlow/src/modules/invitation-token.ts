import { createHmac, timingSafeEqual } from "node:crypto";

import { config } from "../config.js";

export interface InvitationClaims {
  email: string;
  invitationId: string;
  tenantId: string;
}

function signatureFor(encodedPayload: string): string {
  return createHmac("sha256", config.invitationSecret).update(encodedPayload).digest("base64url");
}

export function createInvitationToken(claims: InvitationClaims): string {
  const payload = Buffer.from(JSON.stringify(claims)).toString("base64url");
  return `${payload}.${signatureFor(payload)}`;
}

export function verifyInvitationToken(token: string): InvitationClaims {
  const [payload, signature, extra] = token.split(".");
  if (payload === undefined || signature === undefined || extra !== undefined) {
    throw new Error("Invitation token has an invalid format");
  }

  const expected = Buffer.from(signatureFor(payload));
  const actual = Buffer.from(signature);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    throw new Error("Invitation token signature is invalid");
  }

  const parsed: unknown = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
  if (
    typeof parsed !== "object" ||
    parsed === null ||
    !("email" in parsed) ||
    !("invitationId" in parsed) ||
    !("tenantId" in parsed) ||
    typeof parsed.email !== "string" ||
    typeof parsed.invitationId !== "string" ||
    typeof parsed.tenantId !== "string"
  ) {
    throw new Error("Invitation token payload is invalid");
  }

  return {
    email: parsed.email,
    invitationId: parsed.invitationId,
    tenantId: parsed.tenantId,
  };
}
