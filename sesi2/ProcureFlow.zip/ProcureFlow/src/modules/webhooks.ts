import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { randomUUID } from "node:crypto";

import { config } from "../config.js";
import { pool } from "../db.js";
import { writeAudit } from "./audit.js";

export interface WebhookView {
  callbackUrl: string;
  deliveryBody: string | null;
  deliveryError: string | null;
  deliveryStatus: string | null;
  id: string;
}

function isPrivateAddress(address: string): boolean {
  if (address === "::1" || address.startsWith("fc") || address.startsWith("fd")) return true;
  if (address.startsWith("fe80:")) return true;
  if (isIP(address) !== 4) return false;

  const octets = address.split(".").map((value) => Number.parseInt(value, 10));
  const first = octets[0];
  const second = octets[1];
  if (first === undefined || second === undefined) return true;
  return (
    first === 10 ||
    first === 127 ||
    (first === 169 && second === 254) ||
    (first === 172 && second >= 16 && second <= 31) ||
    (first === 192 && second === 168)
  );
}

export async function validateWebhookDestination(rawUrl: string): Promise<URL> {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error("Webhook URL is invalid");
  }

  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Webhook URL must use HTTP or HTTPS");
  }
  if (url.username !== "" || url.password !== "") {
    throw new Error("Webhook URL must not include credentials");
  }
  if (url.hostname === "localhost" || url.hostname === "internal-ledger") {
    throw new Error("Webhook URL points to a restricted host");
  }

  if (url.hostname === config.partnerHost) return url;

  let addresses: Array<{ address: string }>;
  try {
    addresses = await lookup(url.hostname, { all: true, verbatim: true });
  } catch {
    throw new Error("Webhook hostname could not be resolved");
  }
  if (addresses.length === 0 || addresses.some(({ address }) => isPrivateAddress(address))) {
    throw new Error("Webhook URL resolves to a restricted network");
  }

  return url;
}

export async function createWebhook(input: {
  callbackUrl: string;
  tenantId: string;
  userId: string;
  vendorId: string;
}): Promise<string> {
  const url = await validateWebhookDestination(input.callbackUrl);
  const webhookId = `hook_${randomUUID()}`;
  await pool.query(
    `INSERT INTO webhook_configs (id, tenant_id, vendor_id, callback_url, created_by)
     VALUES ($1, $2, $3, $4, $5)`,
    [webhookId, input.tenantId, input.vendorId, url.toString(), input.userId],
  );
  await writeAudit({
    action: "webhook.created",
    objectId: webhookId,
    objectType: "webhook",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return webhookId;
}

export async function queueWebhookTest(input: {
  deliveryMode: "diagnostic" | "event";
  tenantId: string;
  userId: string;
  vendorId: string;
  webhookId: string;
}): Promise<string> {
  const webhook = await pool.query(
    `SELECT 1
       FROM webhook_configs
      WHERE id = $1 AND tenant_id = $2 AND vendor_id = $3`,
    [input.webhookId, input.tenantId, input.vendorId],
  );
  if (webhook.rowCount !== 1) throw new Error("Webhook does not exist");

  const deliveryId = `delivery_${randomUUID()}`;
  await pool.query(
    `INSERT INTO webhook_deliveries (id, webhook_id, delivery_mode, status)
     VALUES ($1, $2, $3, 'pending')`,
    [deliveryId, input.webhookId, input.deliveryMode],
  );
  await writeAudit({
    action: "webhook.test_queued",
    objectId: input.webhookId,
    objectType: "webhook",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return deliveryId;
}

export async function webhooksForVendor(
  tenantId: string,
  vendorId: string,
): Promise<WebhookView[]> {
  const result = await pool.query<{
    callback_url: string;
    delivery_body: string | null;
    delivery_error: string | null;
    delivery_status: string | null;
    id: string;
  }>(
    `SELECT w.id,
            w.callback_url,
            d.status AS delivery_status,
            d.response_body AS delivery_body,
            d.error_message AS delivery_error
       FROM webhook_configs w
  LEFT JOIN LATERAL (
         SELECT status, response_body, error_message
           FROM webhook_deliveries
          WHERE webhook_id = w.id
          ORDER BY created_at DESC
          LIMIT 1
       ) d ON true
      WHERE w.tenant_id = $1 AND w.vendor_id = $2
      ORDER BY w.created_at DESC`,
    [tenantId, vendorId],
  );

  return result.rows.map((row) => ({
    callbackUrl: row.callback_url,
    deliveryBody: row.delivery_body,
    deliveryError: row.delivery_error,
    deliveryStatus: row.delivery_status,
    id: row.id,
  }));
}
