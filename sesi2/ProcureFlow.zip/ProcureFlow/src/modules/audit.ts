import { pool } from "../db.js";

export interface AuditEvent {
  action: string;
  detail?: string;
  objectId?: string;
  objectType?: string;
  tenantId?: string;
  userId?: string;
}

export async function writeAudit(event: AuditEvent): Promise<void> {
  await pool.query(
    `INSERT INTO audit_logs
       (tenant_id, user_id, action, object_type, object_id, detail)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [
      event.tenantId ?? null,
      event.userId ?? null,
      event.action,
      event.objectType ?? null,
      event.objectId ?? null,
      event.detail ?? null,
    ],
  );
}

export async function recentAuditForTenant(tenantId: string): Promise<
  Array<{
    action: string;
    createdAt: Date;
    detail: string | null;
    objectId: string | null;
  }>
> {
  const result = await pool.query<{
    action: string;
    created_at: Date;
    detail: string | null;
    object_id: string | null;
  }>(
    `SELECT action, created_at, detail, object_id
       FROM audit_logs
      WHERE tenant_id = $1
      ORDER BY created_at DESC
      LIMIT 12`,
    [tenantId],
  );

  return result.rows.map((row) => ({
    action: row.action,
    createdAt: row.created_at,
    detail: row.detail,
    objectId: row.object_id,
  }));
}
