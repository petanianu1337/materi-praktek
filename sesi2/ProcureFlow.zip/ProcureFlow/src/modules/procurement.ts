import { randomUUID } from "node:crypto";

import { pool } from "../db.js";
import { writeAudit } from "./audit.js";

export interface PurchaseRequestView {
  budgetCents: number;
  description: string;
  exportArtifactKey: string | null;
  id: string;
  state: string;
  tenantId: string;
  tenantName: string;
  title: string;
  vendorId: string | null;
  vendorName: string | null;
}

interface PurchaseRequestRow {
  budget_cents: number;
  description: string;
  export_artifact_key: string | null;
  id: string;
  state: string;
  tenant_id: string;
  tenant_name: string;
  title: string;
  vendor_id: string | null;
  vendor_name: string | null;
}

const baseSelect = `SELECT pr.id,
                           pr.tenant_id,
                           t.name AS tenant_name,
                           pr.vendor_id,
                           v.name AS vendor_name,
                           pr.title,
                           pr.description,
                           pr.state,
                           pr.budget_cents,
                           pr.export_artifact_key
                      FROM purchase_requests pr
                      JOIN tenants t ON t.id = pr.tenant_id
                 LEFT JOIN vendors v ON v.id = pr.vendor_id`;

function mapRow(row: PurchaseRequestRow): PurchaseRequestView {
  return {
    budgetCents: row.budget_cents,
    description: row.description,
    exportArtifactKey: row.export_artifact_key,
    id: row.id,
    state: row.state,
    tenantId: row.tenant_id,
    tenantName: row.tenant_name,
    title: row.title,
    vendorId: row.vendor_id,
    vendorName: row.vendor_name,
  };
}

export async function requestForActiveMember(
  userId: string,
  activeTenantId: string,
  requestId: string,
): Promise<PurchaseRequestView | null> {
  const membership = await pool.query(
    `SELECT 1 FROM memberships WHERE user_id = $1 AND tenant_id = $2`,
    [userId, activeTenantId],
  );
  if (membership.rowCount !== 1) return null;

  const result = await pool.query<PurchaseRequestRow>(`${baseSelect} WHERE pr.id = $1`, [
    requestId,
  ]);
  const row = result.rows[0];
  return row === undefined ? null : mapRow(row);
}

export async function requestInTenant(
  activeTenantId: string,
  requestId: string,
): Promise<PurchaseRequestView | null> {
  const result = await pool.query<PurchaseRequestRow>(
    `${baseSelect} WHERE pr.id = $1 AND pr.tenant_id = $2`,
    [requestId, activeTenantId],
  );
  const row = result.rows[0];
  return row === undefined ? null : mapRow(row);
}

export async function requestsForTenant(tenantId: string): Promise<PurchaseRequestView[]> {
  const result = await pool.query<PurchaseRequestRow>(
    `${baseSelect} WHERE pr.tenant_id = $1 ORDER BY pr.created_at DESC`,
    [tenantId],
  );
  return result.rows.map(mapRow);
}

export async function requestsForVendor(
  tenantId: string,
  vendorId: string,
): Promise<PurchaseRequestView[]> {
  const result = await pool.query<PurchaseRequestRow>(
    `${baseSelect}
      WHERE pr.tenant_id = $1 AND pr.vendor_id = $2
      ORDER BY pr.created_at DESC`,
    [tenantId, vendorId],
  );
  return result.rows.map(mapRow);
}

export async function createPurchaseRequest(input: {
  budgetCents: number;
  description: string;
  tenantId: string;
  title: string;
  userId: string;
}): Promise<string> {
  const requestId = `pr_${randomUUID()}`;
  await pool.query(
    `INSERT INTO purchase_requests
       (id, tenant_id, requester_id, title, description, state, budget_cents)
     VALUES ($1, $2, $3, $4, $5, 'draft', $6)`,
    [requestId, input.tenantId, input.userId, input.title, input.description, input.budgetCents],
  );
  await writeAudit({
    action: "purchase_request.created",
    objectId: requestId,
    objectType: "purchase_request",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return requestId;
}

export async function transitionPurchaseRequest(input: {
  from: "draft" | "submitted";
  requestId: string;
  tenantId: string;
  to: "submitted" | "approved";
  userId: string;
}): Promise<boolean> {
  const result = await pool.query(
    `UPDATE purchase_requests
        SET state = $1
      WHERE id = $2 AND tenant_id = $3 AND state = $4`,
    [input.to, input.requestId, input.tenantId, input.from],
  );
  if (result.rowCount !== 1) return false;
  await writeAudit({
    action: `purchase_request.${input.to}`,
    objectId: input.requestId,
    objectType: "purchase_request",
    tenantId: input.tenantId,
    userId: input.userId,
  });
  return true;
}
