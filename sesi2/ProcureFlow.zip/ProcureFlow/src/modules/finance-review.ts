import type { InvoiceView } from "./invoices.js";

export interface FinanceReviewView {
  amountCents: number;
  attachmentName: string;
  invoiceId: string;
  noteHtml: string;
  purchaseRequestTitle: string;
  vendorName: string;
}

function renderMultilineNote(note: string): string {
  return note.replaceAll("\r\n", "\n").replaceAll("\n", "<br>");
}

export function prepareFinanceReview(invoice: InvoiceView): FinanceReviewView {
  return {
    amountCents: invoice.amountCents,
    attachmentName: invoice.attachmentName,
    invoiceId: invoice.id,
    noteHtml: renderMultilineNote(invoice.note),
    purchaseRequestTitle: invoice.purchaseRequestTitle,
    vendorName: invoice.vendorName,
  };
}
