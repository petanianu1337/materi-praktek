import { validateWebhookDestination } from "./webhooks.js";

const redirectStatuses = new Set([301, 302, 303, 307, 308]);

export async function fetchWithDestinationPolicy(
  rawUrl: string,
  init: RequestInit,
): Promise<Response> {
  let currentUrl = rawUrl;

  for (let redirects = 0; redirects <= 5; redirects += 1) {
    const approvedUrl = await validateWebhookDestination(currentUrl);
    const response = await fetch(approvedUrl, {
      ...init,
      redirect: "manual",
    });
    if (!redirectStatuses.has(response.status)) return response;

    const location = response.headers.get("location");
    if (location === null) return response;
    currentUrl = new URL(location, approvedUrl).toString();
  }

  throw new Error("Webhook exceeded the redirect limit");
}
