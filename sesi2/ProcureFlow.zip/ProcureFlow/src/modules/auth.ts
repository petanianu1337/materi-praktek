import { compare } from "bcryptjs";

import { pool } from "../db.js";
import type { MembershipSummary, Role, UserContext } from "../domain.js";

export async function authenticate(email: string, password: string): Promise<string | null> {
  const result = await pool.query<{ id: string; password_hash: string }>(
    `SELECT id, password_hash FROM users WHERE lower(email) = lower($1)`,
    [email.trim()],
  );
  const user = result.rows[0];
  if (user === undefined) return null;

  return (await compare(password, user.password_hash)) ? user.id : null;
}

export async function firstTenantForUser(userId: string): Promise<string | null> {
  const result = await pool.query<{ tenant_id: string }>(
    `SELECT tenant_id
       FROM memberships
      WHERE user_id = $1
      ORDER BY created_at, tenant_id
      LIMIT 1`,
    [userId],
  );
  return result.rows[0]?.tenant_id ?? null;
}

export async function userContext(
  userId: string,
  activeTenantId: string,
): Promise<UserContext | null> {
  const result = await pool.query<{
    display_name: string;
    email: string;
    role: Role;
    tenant_id: string;
    tenant_name: string;
    user_id: string;
    vendor_id: string | null;
  }>(
    `SELECT u.id AS user_id,
            u.email,
            u.display_name,
            m.tenant_id,
            t.name AS tenant_name,
            m.role,
            m.vendor_id
       FROM users u
       JOIN memberships m ON m.user_id = u.id
       JOIN tenants t ON t.id = m.tenant_id
      WHERE u.id = $1 AND m.tenant_id = $2`,
    [userId, activeTenantId],
  );
  const row = result.rows[0];
  if (row === undefined) return null;

  return {
    activeTenantId: row.tenant_id,
    activeTenantName: row.tenant_name,
    displayName: row.display_name,
    email: row.email,
    id: row.user_id,
    role: row.role,
    vendorId: row.vendor_id,
  };
}

export async function membershipsForUser(userId: string): Promise<MembershipSummary[]> {
  const result = await pool.query<{
    role: Role;
    tenant_id: string;
    tenant_name: string;
  }>(
    `SELECT m.tenant_id, t.name AS tenant_name, m.role
       FROM memberships m
       JOIN tenants t ON t.id = m.tenant_id
      WHERE m.user_id = $1
      ORDER BY t.name`,
    [userId],
  );

  return result.rows.map((row) => ({
    role: row.role,
    tenantId: row.tenant_id,
    tenantName: row.tenant_name,
  }));
}

export async function hasMembership(userId: string, tenantId: string): Promise<boolean> {
  const result = await pool.query<{ exists: boolean }>(
    `SELECT EXISTS(
       SELECT 1 FROM memberships WHERE user_id = $1 AND tenant_id = $2
     ) AS exists`,
    [userId, tenantId],
  );
  return result.rows[0]?.exists ?? false;
}
