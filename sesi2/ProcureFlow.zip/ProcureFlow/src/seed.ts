import { hash } from "bcryptjs";

import { config } from "./config.js";
import { closePool, pool } from "./db.js";
import { createInvitationToken } from "./modules/invitation-token.js";

const ids = {
  acmeTenant: "tenant_9f6c2a11-acme",
  beaconVendor: "vendor_6c2d14aa-beacon",
  confidentialRequest: "pr_7f4e9c21-quarterly-platform",
  existingInvoice: "inv_2ad8335c-office-network",
  employeeInvitation: "invite_24d972aa-employee",
  financeUser: "user_45a07d8e-finance",
  invitation: "invite_36b9e0c2-northstar",
  managerUser: "user_75fd830b-manager",
  northstarTenant: "tenant_3a1e8f77-northwind",
  northstarVendor: "vendor_e52bf197-northstar",
  outsiderUser: "user_2ac94581-alex",
  safeRequest: "pr_19a34d70-network-refresh",
  seededArtifact: "art_86df2a40-0d47-4c2b-b868-713f56919ab4",
  seededExportJob: "job_c65144da-quarterly-export",
  tenantAdminUser: "user_8f13ca74-admin",
  tenantEmployeeUser: "user_9d1a274b-employee",
  vendorUser: "user_a681dc20-vendor",
} as const;

const demoPassword = "ProcureFlow!2026";

export async function seed(): Promise<void> {
  const existing = await pool.query<{ count: string }>("SELECT count(*) FROM users");
  if (existing.rows[0]?.count !== "0") {
    console.log("Seed data already exists");
    return;
  }

  const passwordHash = await hash(demoPassword, 12);
  const invitationToken = createInvitationToken({
    email: "newvendor@northstar.example",
    invitationId: ids.invitation,
    tenantId: ids.acmeTenant,
  });
  const invitationUrl = `${config.baseUrl}/invitations/${invitationToken}`;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `INSERT INTO tenants (id, name)
       VALUES ($1, 'Acme Manufacturing'), ($2, 'Northwind Workshop')`,
      [ids.acmeTenant, ids.northstarTenant],
    );

    await client.query(
      `INSERT INTO users (id, email, display_name, password_hash)
       VALUES
         ($1, 'alex@northwind.example', 'Alex Morgan', $7),
         ($2, 'admin@acme.example', 'Avery Admin', $7),
         ($3, 'employee@acme.example', 'Emery Employee', $7),
         ($4, 'manager@acme.example', 'Morgan Manager', $7),
         ($5, 'finance@acme.example', 'Finley Finance', $7),
         ($6, 'vendor@beacon.example', 'Blair Vendor', $7)`,
      [
        ids.outsiderUser,
        ids.tenantAdminUser,
        ids.tenantEmployeeUser,
        ids.managerUser,
        ids.financeUser,
        ids.vendorUser,
        passwordHash,
      ],
    );

    await client.query(
      `INSERT INTO vendors (id, tenant_id, name)
       VALUES
         ($1, $3, 'Beacon Office Supply'),
         ($2, $3, 'Northstar Systems')`,
      [ids.beaconVendor, ids.northstarVendor, ids.acmeTenant],
    );

    await client.query(
      `INSERT INTO memberships (id, user_id, tenant_id, role, vendor_id)
       VALUES
         ('membership_alex_northwind', $1, $7, 'employee', NULL),
         ('membership_admin_acme', $2, $8, 'admin', NULL),
         ('membership_employee_acme', $3, $8, 'employee', NULL),
         ('membership_manager_acme', $4, $8, 'manager', NULL),
         ('membership_finance_acme', $5, $8, 'finance', NULL),
         ('membership_vendor_acme', $6, $8, 'vendor', $9)`,
      [
        ids.outsiderUser,
        ids.tenantAdminUser,
        ids.tenantEmployeeUser,
        ids.managerUser,
        ids.financeUser,
        ids.vendorUser,
        ids.northstarTenant,
        ids.acmeTenant,
        ids.beaconVendor,
      ],
    );

    await client.query(
      `INSERT INTO purchase_requests
         (id, tenant_id, requester_id, vendor_id, title, description, state, budget_cents, export_artifact_key)
       VALUES
         ($1, $4, $5, $6, 'Quarterly platform renewal',
          'Confidential renewal plan for the finance platform.', 'exported', 14850000, $7),
         ($2, $4, $5, $8, 'Office network refresh',
          'Replace access points on the second floor.', 'invoiced', 2850000, NULL),
         ($3, $9, $10, NULL, 'Workshop safety equipment',
          'Protective equipment for the fabrication room.', 'submitted', 720000, NULL)`,
      [
        ids.confidentialRequest,
        ids.safeRequest,
        "pr_8da39211-safety-equipment",
        ids.acmeTenant,
        ids.tenantEmployeeUser,
        ids.northstarVendor,
        ids.seededArtifact,
        ids.beaconVendor,
        ids.northstarTenant,
        ids.outsiderUser,
      ],
    );

    await client.query(
      `INSERT INTO invitations
         (id, tenant_id, email, role, vendor_id, onboarding_request_id, expires_at)
       VALUES
         ($1, $3, 'newvendor@northstar.example', 'vendor', $4, $5, now() + interval '30 days'),
         ($2, $3, 'newemployee@acme.example', 'employee', NULL, NULL, now() + interval '30 days')`,
      [
        ids.invitation,
        ids.employeeInvitation,
        ids.acmeTenant,
        ids.northstarVendor,
        ids.confidentialRequest,
      ],
    );

    await client.query(
      `INSERT INTO lab_messages (id, recipient, subject, body)
       VALUES ('message_vendor_invitation', 'newvendor@northstar.example',
               'You are invited to ProcureFlow', $1)`,
      [`Open the invitation to finish vendor onboarding: ${invitationUrl}`],
    );

    await client.query(
      `INSERT INTO invoices
         (id, tenant_id, purchase_request_id, vendor_id, note, attachment_name, amount_cents, created_by)
       VALUES ($1, $2, $3, $4,
               'Delivery is scheduled for the first Monday of next month.',
               'network-refresh-invoice.txt', 2850000, $5)`,
      [ids.existingInvoice, ids.acmeTenant, ids.safeRequest, ids.beaconVendor, ids.vendorUser],
    );

    await client.query(
      `INSERT INTO export_jobs
         (id, tenant_id, requested_by, artifact_key, status, finished_at)
       VALUES ($1, $2, $3, $4, 'completed', now())`,
      [ids.seededExportJob, ids.acmeTenant, ids.financeUser, ids.seededArtifact],
    );

    await client.query(
      `INSERT INTO export_artifacts
         (artifact_key, tenant_id, content_type, content)
       VALUES ($1, $2, 'application/json', $3)`,
      [
        ids.seededArtifact,
        ids.acmeTenant,
        JSON.stringify(
          {
            classification: "confidential",
            marker: "ACME-Q4-FORECAST-7B92",
            records: [
              {
                amountCents: 14850000,
                purchaseRequestId: ids.confidentialRequest,
                title: "Quarterly platform renewal",
              },
            ],
            tenant: "Acme Manufacturing",
          },
          null,
          2,
        ),
      ],
    );

    await client.query(
      `INSERT INTO audit_logs (tenant_id, user_id, action, object_type, object_id, detail)
       VALUES
         ($1, $2, 'purchase_request.exported', 'purchase_request', $3, 'Quarterly export completed'),
         ($1, $4, 'invoice.created', 'invoice', $5, 'Vendor invoice received')`,
      [
        ids.acmeTenant,
        ids.financeUser,
        ids.confidentialRequest,
        ids.vendorUser,
        ids.existingInvoice,
      ],
    );

    await client.query("COMMIT");
    console.log("Seed data created");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  seed()
    .finally(closePool)
    .catch((error: unknown) => {
      console.error("Database seed failed", error);
      process.exitCode = 1;
    });
}
